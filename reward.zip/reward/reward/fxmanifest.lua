fx_version 'adamant'
games { 'gta5' };

client_script 'client.lua'
server_script 'server.lua'
shared_script '@es_extended/imports.lua'
